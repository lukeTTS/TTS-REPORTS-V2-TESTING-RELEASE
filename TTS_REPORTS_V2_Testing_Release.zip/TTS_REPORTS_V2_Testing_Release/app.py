from pathlib import Path
from uuid import uuid4
from datetime import datetime, timezone
import hashlib
import hmac
import json
import os

from flask import Flask, flash, jsonify, redirect, render_template, request, send_file, url_for, session

from report_core import GeneralData, generate_report, preview_padfx

BASE = Path(__file__).resolve().parent
UPLOAD_DIR = BASE / "uploads"
OUTPUT_DIR = BASE / "output"
LICENCE_TABLE_PATH = BASE / "licence_codes.json"
TERMS_LOG_PATH = BASE / "terms_acceptance_log.jsonl"
SALE_ITEMS_PATH = BASE / "sale_items.json"
TERMS_VERSION = "TTS_REPORTS_TERMS_2026_06"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("TTS_REPORTS_SECRET_KEY", "tts-reports-v2-testing-release")


def _normalise_licence_code(code: str) -> str:
    return "".join(str(code or "").strip().upper().split())


def _hash_licence_code(code: str) -> str:
    return hashlib.sha256(_normalise_licence_code(code).encode("utf-8")).hexdigest()


def _load_licence_hashes() -> set[str]:
    """Load the hashed licence table.

    The browser submits a plain licence code once. The server hashes the entered
    value and compares it with this table. Raw licence codes are not needed in
    the app code.
    """
    try:
        data = json.loads(LICENCE_TABLE_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return set()
    except json.JSONDecodeError:
        return set()
    return {str(item.get("sha256", "")).lower() for item in data.get("licences", []) if item.get("sha256")}


def _is_activated() -> bool:
    return bool(
        session.get("licence_activated") is True
        and session.get("licence_hash")
        and session.get("terms_accepted_version") == TERMS_VERSION
    )


def _require_activation_response():
    if _is_activated():
        return None
    if request.path.startswith("/preview") or request.path.startswith("/report_preview"):
        return jsonify({"error": "Licence activation is required before using TTS Reports."}), 403
    flash("Licence activation is required before using TTS Reports.")
    return redirect(url_for("index"))


def _terms_accepted_for_request() -> bool:
    return session.get("terms_accepted_version") == TERMS_VERSION


def _log_terms_acceptance(action: str):
    entry = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "terms_version": TERMS_VERSION,
        "action": action,
        "licence_hash": session.get("licence_hash", ""),
        "remote_addr": request.headers.get("X-Forwarded-For", request.remote_addr or ""),
        "user_agent": request.headers.get("User-Agent", ""),
    }
    with TERMS_LOG_PATH.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
    session["terms_accepted_version"] = TERMS_VERSION


def _require_terms_response(action: str):
    # Terms acceptance is completed and logged on the activation screen.
    # This guard remains on upload/report routes so a terms-version change
    # automatically re-locks the app until the user accepts the current version.
    if _terms_accepted_for_request():
        return None
    message = "Please accept the current terms on the activation screen before uploading files or generating reports."
    if request.path.startswith("/preview") or request.path.startswith("/report_preview"):
        return jsonify({"error": message}), 403
    flash(message)
    return redirect(url_for("index"))


def _is_allowed_upload_file(filename: str) -> bool:
    """Customer-facing upload gate for V1.0.

    Existing parser support remains in report_core.py. This route-level gate only
    allows aPAT PDF report uploads in the user interface/customer workflow.
    """
    return Path(filename or "").suffix.lower() == ".pdf"


def form_to_general_data(form) -> dict:
    multi = {
        "type_of_equipment": form.getlist("type_of_equipment"),
        "reason_for_test": form.getlist("reason_for_test"),
        "attachments": form.getlist("attachments"),
        "method_of_labelling": form.getlist("method_of_labelling"),
    }
    fields = {}
    for f in GeneralData.__dataclass_fields__:
        if f in multi:
            fields[f] = multi[f]
        else:
            fields[f] = form.get(f, "")
    return fields


@app.route("/")
def index():
    if not _is_activated():
        return render_template("activation.html", terms_version=TERMS_VERSION)
    return render_template("index.html", terms_version=TERMS_VERSION)


@app.post("/activate")
def activate():
    entered_code = request.form.get("licence_code", "")
    terms_checked = request.form.get("terms_acceptance") == "accepted"
    submitted_terms_version = request.form.get("terms_version", "")
    if not terms_checked or submitted_terms_version != TERMS_VERSION:
        return render_template(
            "activation.html",
            terms_version=TERMS_VERSION,
            error="Please accept the current terms before activating TTS Reports.",
        ), 403

    entered_hash = _hash_licence_code(entered_code)
    valid_hashes = _load_licence_hashes()
    if any(hmac.compare_digest(entered_hash, valid_hash) for valid_hash in valid_hashes):
        session.clear()
        session["licence_activated"] = True
        session["licence_hash"] = entered_hash
        _log_terms_acceptance("licence_activation")
        return redirect(url_for("index"))
    return render_template("activation.html", terms_version=TERMS_VERSION, error="Invalid licence code. Please check the code and try again."), 403


@app.post("/deactivate")
def deactivate():
    session.clear()
    return redirect(url_for("index"))




@app.get("/sale_items")
def sale_items():
    activation_response = _require_activation_response()
    if activation_response:
        return activation_response
    try:
        data = json.loads(SALE_ITEMS_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError:
        data = {"items": []}
    except json.JSONDecodeError:
        data = {"items": [], "error": "sale_items.json is not valid JSON"}
    if not isinstance(data, dict):
        data = {"items": []}
    data.setdefault("items", [])
    return jsonify(data)


@app.post("/preview")
def preview():
    activation_response = _require_activation_response()
    if activation_response:
        return activation_response
    terms_response = _require_terms_response("upload_preview")
    if terms_response:
        return terms_response
    f = request.files.get("project_file") or request.files.get("padfx_file") or request.files.get("data_file")
    if not f or not _is_allowed_upload_file(f.filename):
        return jsonify({"error": "Please upload an aPAT PDF report (.pdf). Other parser formats remain in the codebase but are not available for customer upload in this build."}), 400
    job_id = uuid4().hex
    path = UPLOAD_DIR / f"{job_id}_{Path(f.filename).name}"
    f.save(path)
    try:
        result = preview_padfx(path, filter_mode=request.form.get("filter_mode", "latest"), start_date=request.form.get("filter_start_date") or None, end_date=request.form.get("filter_end_date") or None)
        session["last_project_path"] = str(path)
        session["last_project_filename"] = f.filename
        result["filename"] = f.filename
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


def _generate_report_file_from_request():
    f = request.files.get("project_file") or request.files.get("padfx_file") or request.files.get("data_file")
    job_id = uuid4().hex

    if f:
        if not _is_allowed_upload_file(f.filename):
            raise ValueError("Please upload an aPAT PDF report (.pdf).")
        project_path = UPLOAD_DIR / f"{job_id}_{Path(f.filename).name}"
        f.save(project_path)
        session["last_project_path"] = str(project_path)
        session["last_project_filename"] = f.filename
    else:
        # Reuse the file already imported by /preview. This prevents report generation
        # failing when the browser clears or omits the file input on a later submit.
        saved_path = session.get("last_project_path")
        saved_name = session.get("last_project_filename", "")
        project_path = Path(saved_path) if saved_path else None
        if not project_path or not project_path.exists() or not _is_allowed_upload_file(saved_name):
            raise ValueError("Please upload an aPAT PDF report (.pdf).")

    general = form_to_general_data(request.form)
    report_type = request.form.get("report_type", "pro")
    include_cards = request.form.get("include_asset_cards") == "on" and report_type == "pro"
    filter_mode = request.form.get("filter_mode", "latest")
    start_date = request.form.get("filter_start_date") or None
    end_date = request.form.get("filter_end_date") or None
    pdf_path = OUTPUT_DIR / f"tts_pro_report_{report_type}_{job_id}.pdf"
    generate_report(project_path, pdf_path, general, include_asset_cards=include_cards, report_type=report_type, filter_mode=filter_mode, start_date=start_date, end_date=end_date)
    if report_type in {"retest", "upcoming_retest", "upcoming"}:
        download_name = "tts_upcoming_retest_report.pdf"
    else:
        download_name = f"tts_pro_report_{report_type}.pdf"
    return pdf_path, download_name


@app.post("/generate")
def generate():
    activation_response = _require_activation_response()
    if activation_response:
        return activation_response
    terms_response = _require_terms_response("generate_report")
    if terms_response:
        return terms_response
    try:
        pdf_path, download_name = _generate_report_file_from_request()
    except ValueError as e:
        flash(str(e))
        return redirect(url_for("index"))
    except Exception as e:
        flash(f"Could not generate report: {e}")
        return redirect(url_for("index"))
    return send_file(pdf_path, as_attachment=True, download_name=download_name)


@app.post("/report_preview")
def report_preview():
    activation_response = _require_activation_response()
    if activation_response:
        return activation_response
    terms_response = _require_terms_response("report_preview")
    if terms_response:
        return terms_response
    try:
        pdf_path, download_name = _generate_report_file_from_request()
    except Exception as e:
        return f"<html><body style='font-family:Arial;padding:24px'><h2>Could not preview report</h2><p>{e}</p></body></html>", 400
    session["last_preview_pdf_path"] = str(pdf_path)
    session["last_preview_download_name"] = download_name
    return send_file(pdf_path, as_attachment=False, download_name=download_name, mimetype="application/pdf")


@app.get("/download_preview")
def download_preview():
    activation_response = _require_activation_response()
    if activation_response:
        return activation_response
    pdf_path = Path(session.get("last_preview_pdf_path", ""))
    download_name = session.get("last_preview_download_name", "tts_report_preview.pdf")
    if not pdf_path.exists():
        flash("Please preview a report before exporting it.")
        return redirect(url_for("index"))
    return send_file(pdf_path, as_attachment=True, download_name=download_name)

