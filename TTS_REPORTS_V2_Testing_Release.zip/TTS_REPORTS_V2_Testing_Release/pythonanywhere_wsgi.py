"""PythonAnywhere WSGI reference for TTS_REPORTS_V2_Testing_Release.

Copy this content into the PythonAnywhere WSGI file and update the project_dir
path to match the folder where this release has been uploaded.
"""

import sys
from pathlib import Path

project_dir = Path('/home/yourusername/mysite')
if str(project_dir) not in sys.path:
    sys.path.insert(0, str(project_dir))

from app import app as application  # noqa: E402
